﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System.IO;
using System;

public class UIManager : MonoBehaviour {

    public enum Algorithm {
        DIJKSTRA,
        WALLFOLLOW,
        ASTAR
    }
    Algorithm currentAlgorithm = Algorithm.DIJKSTRA;

    public Dropdown algsDropdown;
    public GameObject startHandle, endHandle;
    public GameObject mazeImage, workingPanel;
    public GameObject resDownscaleValueText, imgThresholdValueText;
    public GameObject resDownscaleSlider, imgThresholdSlider;
    public GameObject textResults;
    public WebcamManager wcManager;

    int currentImageThreshold = 150;
    int currentImageScale = 1;

    int timeStart;
    int lastNoSteps;
    bool lastIfSuccessful, lastIfTimedOut;
    bool ifFlaggedToStopTimer = false;
    bool ifFlaggedToSolveMazeA = false;
    bool ifFlaggedToSolveMazeB = false;

    bool ifDraggingStartHandle = false;
    bool ifDraggingEndHandle = false;

    bool ifShowingEdges = false;
    bool ifWallsAirFlipped = false;

    bool ifImageChosen = false;

    Texture2D currentTexture, currentTextureParsed, originalTexture;
    bool[,] currentMaze;

    // Use this for initialization
    void Start () {
        currentTexture = new Texture2D(0, 0);
        originalTexture = new Texture2D(0, 0);
	}
	
	// Update is called once per frame
	void Update () {
		if (ifDraggingStartHandle) {
            startHandle.transform.position = GetDragHandlePosition();
        }

        if (ifDraggingEndHandle) {
            endHandle.transform.position = GetDragHandlePosition();
        }

        if (ifFlaggedToStopTimer) {
            Debug.Log("Time taken: " + (Environment.TickCount - timeStart) / 1000f + "s");
            ifFlaggedToStopTimer = false;
            if (lastIfSuccessful) {
                textResults.GetComponent<Text>().text =
                    "Steps: " + lastNoSteps.ToString() + "\nTime: " + (Environment.TickCount - timeStart) / 1000f + "s";
            }
            else {
                if (lastIfTimedOut) {
                    textResults.GetComponent<Text>().text = "<b>No path found!</b>\n(Timed out)";
                }
                else {
                    textResults.GetComponent<Text>().text = "<b>No path found!</b>";
                }
                
            }
        }

        if (ifFlaggedToSolveMazeA) {
            if (ifFlaggedToSolveMazeB) {
                ifFlaggedToSolveMazeB = false;
            }
            else {
                RedrawImage();
                SolveMaze();
                ifFlaggedToSolveMazeA = false;
            }
        }
	}

    public void OnTakePictureClick() {
        wcManager.StartWebcamInterface(this);
    }

    //Work on "duplicate code" here?
    public void OnPictureTaken(Texture2D photo) {
        originalTexture = photo;
        currentTexture.LoadImage(originalTexture.EncodeToPNG());
        bool useless;
        ImageParser.ParseImage(originalTexture, currentImageThreshold, 1.0d / currentImageScale, out currentMaze, out currentTextureParsed, out useless, ifWallsAirFlipped);
        RedrawImage();

        ifImageChosen = true;
    }

    public void OnLoadPictureClick() {

        string outer = EditorUtility.OpenFilePanel("Choose an image", "", "png");
        byte[] bytes = File.ReadAllBytes(outer);
        originalTexture.LoadImage(bytes);
        currentTexture.LoadImage(originalTexture.EncodeToPNG());
        bool useless;
        ImageParser.ParseImage(originalTexture, currentImageThreshold, 1.0d / currentImageScale, out currentMaze, out currentTextureParsed, out useless, ifWallsAirFlipped);
        RedrawImage();

        /*string workingText = "";
        for (int i = 0; i < currentMaze.GetLength(0); i++) {
            for (int j = 0; j < currentMaze.GetLength(1); j++) {
                if (j == currentMaze.GetLength(1) - 1) {
                    workingText = workingText + (currentMaze[i, j] ? 1 : 0);
                }
                else {
                    workingText = workingText + (currentMaze[i, j] ? 1 : 0) + " ";
                }
            }
            if (i != currentMaze.GetLength(0) - 1) {
                workingText += Environment.NewLine;
            }
        }

        File.WriteAllText("somethinsomethin.txt", workingText);*/

        ifImageChosen = true;
    }

    public void OnSavePictureClick() {
        if (!ifImageChosen) return;
        string outer = EditorUtility.SaveFilePanel("Save image", "", "maze_solved.png", "png");
        byte[] bytes = (ifShowingEdges ? currentTextureParsed : currentTexture).EncodeToPNG();
        File.WriteAllBytes(outer, bytes);
    }

    public void OnAlgorithmChanged(int algorithmIndex) {
        currentAlgorithm = (Algorithm)algorithmIndex;
    }

    public void OnSolveMazeClick() {
        if (!ifImageChosen) return;
        workingPanel.SetActive(true);
        ifFlaggedToSolveMazeA = true;
        ifFlaggedToSolveMazeB = true;
    }

    public void SolveMaze() {

        //Make this work with algorithms in general!
        List<Vector2> finalPath = new List<Vector2>();

        /////////////////////////////////////////////////////////////// USE INTEGERS
        bool ifSuccessful = false;
        bool ifTimedOut = false;
        timeStart = Environment.TickCount;
        switch (currentAlgorithm) {
            case Algorithm.ASTAR:
                try {
                    MazeUtility.NavigateAStar(currentMaze,
                            RoundVector2(GetImagePositionFromMousePosition(startHandle.transform.position)),
                            RoundVector2(GetImagePositionFromMousePosition(endHandle.transform.position)),
                            out finalPath, out ifSuccessful);
                }
                catch (ArgumentOutOfRangeException) {
                    Debug.LogError("last minute ArgumentOutOfRangeException!");
                    finalPath = new List<Vector2>();
                    ifSuccessful = false;
                }
                Debug.Log("A* success: " + ifSuccessful);
                break;
            case Algorithm.DIJKSTRA:
                MazeUtility.NavigateDijkstra(currentMaze,
                            RoundVector2(GetImagePositionFromMousePosition(startHandle.transform.position)),
                            RoundVector2(GetImagePositionFromMousePosition(endHandle.transform.position)),
                        out finalPath, out ifSuccessful);
                Debug.Log("Dijkstra success: " + ifSuccessful);
                break;
            case Algorithm.WALLFOLLOW:
                MazeUtility.NavigateWallFollow(currentMaze,
                            RoundVector2(GetImagePositionFromMousePosition(startHandle.transform.position)),
                            RoundVector2(GetImagePositionFromMousePosition(endHandle.transform.position)),
                        out finalPath, out ifSuccessful, out ifTimedOut);
                Debug.Log("Wall-follow success: " + ifSuccessful);
                break;
            default:
                Debug.Log("screw this");
                ifSuccessful = false;
                break;
        }

        lastIfSuccessful = ifSuccessful;
        lastIfTimedOut = ifTimedOut;

        ifFlaggedToStopTimer = true;

        currentTexture.LoadImage(originalTexture.EncodeToPNG());
        ReparseImage();

        if (ifSuccessful) {
            //Debug.Log("length: " + finalPath.Count);
            for (int i = 1; i < finalPath.Count; i++) {
                currentTexture.SetPixel((int)finalPath[i].x, (int)finalPath[i].y, Color.red);
                currentTextureParsed.SetPixel((int)finalPath[i].x, (int)finalPath[i].y, Color.red);
                //Debug.Log("Point " + i + ": " + finalPath[i].x + " " + finalPath[i].y);
            }
        }

        currentTexture.Apply();
        currentTextureParsed.Apply();

        lastNoSteps = finalPath.Count;

        workingPanel.SetActive(false);
    }

    public void OnResolutionDownscaleChanged() {
        int value = (int)resDownscaleSlider.GetComponent<Slider>().value;
        currentImageScale = value;
        resDownscaleValueText.GetComponent<Text>().text = value.ToString();
        if (!ifImageChosen) return;
        ReparseImage();
    }

    public void OnImageThresholdChanged() {
        int value = (int)imgThresholdSlider.GetComponent<Slider>().value;
        currentImageThreshold = value;
        imgThresholdValueText.GetComponent<Text>().text = value.ToString();
        if (!ifImageChosen) return;
        ReparseImage();
    }

    public void OnShowEdgesClicked(bool value) {
        ifShowingEdges = value;
        if (!ifImageChosen) return;
        RedrawImage();
    }

    public void OnFlipWallsAirClicked(bool value) {
        ifWallsAirFlipped = value;
        if (!ifImageChosen) return;
        ReparseImage();
    }

    public void OnStartHandleBeginDrag() {
        ifDraggingStartHandle = true;
    }

    public void OnStartHandleEndDrag() {
        ifDraggingStartHandle = false;
    }

    public void OnEndHandleBeginDrag() {
        ifDraggingEndHandle = true;
    }

    public void OnEndHandleEndDrag() {
        ifDraggingEndHandle = false;
    }

    public Vector2 GetDragHandlePosition() {
        Vector2 newPos = Input.mousePosition;
        newPos.x = Mathf.Clamp(newPos.x,
            mazeImage.transform.position.x - mazeImage.GetComponent<RectTransform>().rect.width / 2,
            mazeImage.transform.position.x + mazeImage.GetComponent<RectTransform>().rect.width / 2);
        newPos.y = Mathf.Clamp(newPos.y,
            mazeImage.transform.position.y - mazeImage.GetComponent<RectTransform>().rect.height / 2,
            mazeImage.transform.position.y + mazeImage.GetComponent<RectTransform>().rect.height / 2);
        return newPos;
    }

    void RedrawImage() {
        //currentTexture.LoadImage(originalTexture.EncodeToPNG());
        mazeImage.GetComponent<RawImage>().texture = ifShowingEdges ? currentTextureParsed : currentTexture;
        mazeImage.GetComponent<RawImage>().texture.filterMode = FilterMode.Point;
    }

    Vector2 GetImagePositionFromMousePosition(Vector3 mousePos) {
        Vector2 zeroedPos = mousePos - mazeImage.transform.position;
        zeroedPos.x *= currentTextureParsed.width  / mazeImage.GetComponent<RectTransform>().rect.width;
        zeroedPos.y *= currentTextureParsed.height / mazeImage.GetComponent<RectTransform>().rect.height;
        zeroedPos.x += currentTextureParsed.width / 2;
        zeroedPos.y += currentTextureParsed.height / 2;
        return zeroedPos;
    }

    Vector3 RoundVector3(Vector3 input) {
        return new Vector3(Mathf.Round(input.x), Mathf.Round(input.y), Mathf.Round(input.z));
    }

    Vector2 RoundVector2(Vector2 input) {
        return new Vector2(Mathf.Round(input.x), Mathf.Round(input.y));
    }

    void ReparseImage() {
        bool ifIPSuccessful;
        Texture2D ctpTemp = new Texture2D(0, 0);
        ctpTemp.LoadImage(currentTextureParsed.EncodeToPNG());
        ImageParser.ParseImage(originalTexture, currentImageThreshold, 1.0d / currentImageScale, out currentMaze, out currentTextureParsed, out ifIPSuccessful, ifWallsAirFlipped);

        if (!ifIPSuccessful) {
            currentTextureParsed.LoadImage(ctpTemp.EncodeToPNG());
        }

        RedrawImage();
    }
}
