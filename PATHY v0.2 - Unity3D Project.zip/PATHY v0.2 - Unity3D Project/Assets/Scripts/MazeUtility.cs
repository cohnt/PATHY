﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeUtility {

    public enum Direction {
        UP,
        DOWN,
        LEFT,
        RIGHT,
        NONE
    };

    public class Vector2UShort {
        public ushort x, y;
        public Vector2UShort(ushort xC, ushort yC) {
            x = xC;
            y = yC;
        }
        public Vector2UShort() {
            x = 0;
            y = 0;
        }

        public bool Equals(Vector2UShort vOther) {
            return (x == vOther.x) && (y == vOther.y);
        }
    }

    public static void NavigateDijkstra(bool[,] grid, Vector2 start, Vector2 end, out List<Vector2> finalPath, out bool ifSuccessful) {
        ushort[,] ushortGrid = new ushort[grid.GetLength(0), grid.GetLength(1)];

        for (int i = 0; i < grid.GetLength(0); i++) {
            for (int j = 0; j < grid.GetLength(1); j++) {
                ushortGrid[i, j] = grid[i, j] ? (ushort)1 : (ushort)2; //Negation?
            }
        }

        Vector2UShort startV2I = new Vector2UShort((ushort)start.x, (ushort)start.y);
        Vector2UShort endV2I = new Vector2UShort((ushort)end.x, (ushort)end.y);

        NavigateDijkstra(ushortGrid, startV2I, endV2I, out finalPath, out ifSuccessful);
    }


    //1 (start) -> 3
    //0 (air) -> 2
    //-1 (wall) -> 1
    //-2 (end) -> 0
    public static void NavigateDijkstra(ushort[,] grid, Vector2UShort start, Vector2UShort end, out List<Vector2> finalPath, out bool ifSuccessful) {
        //Initialize Variables
        bool notSolved = true, changedVals = false, home = false;
        List<Vector2UShort> toSweep = new List<Vector2UShort>();
        List<Vector2UShort> queue = new List<Vector2UShort>();

        //Begin the sweeps at start
        toSweep.Add(start);

        //curSweep should look for start in the first iteration
        int curSweep = 3;

        for (int k = 0; k < grid.GetLength(0); k++) {
            grid[k, 0] = 1;
            grid[k, grid.GetLength(1) - 1] = 1;
        }
        for (int k = 0; k < grid.GetLength(1); k++) {
            grid[0, k] = 1;
            grid[grid.GetLength(0) - 1, k] = 1;
        }

        //Pad the outside of the maze with a wall (stops index out of bounds)
        //padMaze(grid);
        //Sets Start to 3 and end to 0
        grid[start.x, start.y] = 3;
        grid[end.x, end.y] = 0;

        int i, j;
        int counter = 0;
        //Loop until the maze is solved
        while (notSolved) {
            counter++;
            changedVals = false;
            //Loop through all positions in the image
            for (int a = 0; a < toSweep.Count; a++) {
                i = toSweep[a].x;
                j = toSweep[a].y;

                if (grid[i - 1, j] == 2) {
                    grid[i - 1, j] = (ushort)(curSweep + 1);
                    changedVals = true;
                    queue.Add(new Vector2UShort((ushort)(i - 1), (ushort)j));
                }

                if (grid[i + 1, j] == 2) {
                    grid[i + 1, j] = (ushort)(curSweep + 1);
                    changedVals = true;
                    queue.Add(new Vector2UShort((ushort)(i + 1), (ushort)j));
                }

                if (grid[i, j - 1] == 2) {
                    grid[i, j - 1] = (ushort)(curSweep + 1);
                    changedVals = true;
                    queue.Add(new Vector2UShort((ushort)i, (ushort)(j - 1)));
                }

                if (grid[i, j + 1] == 2) {
                    grid[i, j + 1] = (ushort)(curSweep + 1);
                    changedVals = true;
                    queue.Add(new Vector2UShort((ushort)i, (ushort)(j + 1)));
                }

                //Check if any of the adjacent values are the goal
                if (grid[i - 1, j] == 0 || grid[i + 1, j] == 0 || grid[i, j - 1] == 0 || grid[i, j + 1] == 0) {
                    notSolved = false;
                    break;
                }
            }


            //If we didn't change any values and didn't find the end, we failed (break)
            if (!changedVals) {
                Debug.Log("Oh no.");
                finalPath = new List<Vector2>();
                ifSuccessful = false;
                return;
            }

            //Increment curSweep
            curSweep++;

            //Clear toSweep
            toSweep.Clear();

            //Add all of queue to toSweep
            for (int b = 0; b < queue.Count; b++) {
                toSweep.Add(new Vector2UShort(queue[b].x, queue[b].y));
            }

            queue.Clear();
        }

        Debug.Log("counter " + counter);


        ///////////////

        //Initialize some variables
        finalPath = new List<Vector2> {
            new Vector2(end.x, end.y)
        };
        Vector2UShort curPos = end;
        Vector2UShort nextPos = new Vector2UShort();
        ushort curVal = ushort.MaxValue, temp;
        grid[end.x, end.y] = ushort.MaxValue;
        //This loop traces the shortest path by choosing positions with the lowest value
        while (!home) {

            //Set temp to above value
            temp = grid[curPos.x - 1, curPos.y];
            //If temp is larger than 2 and it is less than curVal, set nextPos to above
            //and set curVal to temp
            if (temp > 2 && temp < curVal) {
                nextPos.x = (ushort)(curPos.x - 1);
                nextPos.y = curPos.y;
                curVal = temp;
            }

            //Same operations done below for bottom, left, and right

            temp = grid[curPos.x + 1, curPos.y];
            if (temp > 2 && temp < curVal) {
                nextPos.x = (ushort)(curPos.x + 1);
                nextPos.y = curPos.y;
                curVal = temp;
            }

            temp = grid[curPos.x, curPos.y - 1];
            if (temp > 2 && temp < curVal) {
                nextPos.x = curPos.x;
                nextPos.y = (ushort)(curPos.y - 1);
                curVal = temp;
            }

            temp = grid[curPos.x, curPos.y + 1];
            if (temp > 2 && temp < curVal) {
                nextPos.x = curPos.x;
                nextPos.y = (ushort)(curPos.y + 1);
                curVal = temp;
            }

            //If we have found the start, set home to true and add start to the path
            if (curVal == 3) {
                home = true;
                finalPath.Add(new Vector2(start.x, start.y));
            }
            //Otherwise add nextPos to the path and set curPos to nextPos
            else {
                finalPath.Add(new Vector2(nextPos.x, nextPos.y));
                curPos = nextPos;
            }
        }

        ifSuccessful = true;
    }

    static double AStarHeuristic(Vector2UShort current, Vector2UShort goal) {
        //Our heuristic is distance-squared
        //It's really distance, but there's no reason to compute the square root, as
        //sqrt is bijective and strictly increasing
        //return pow(goal[0]-current[0], 2) + pow(goal[1]-current[1], 2);

        //New heuristic! Manhattan-Distance
        //https://math.stackexchange.com/questions/139600/how-to-calculate-the-euclidean-and-manhattan-distance
        return Math.Abs(goal.x - current.x) + Math.Abs(goal.y - current.y);
    }

    static Vector2UShort AStarGetCurrentPoint(List<Vector2UShort> openPoints, List<List<double>> f, out int index) {
        int bestIndex = 0;
        int fBest = (int)f[openPoints[0].x][openPoints[0].y]; //does this casting work?
        int fCurrent;
        for (int i = 1; i < openPoints.Count; ++i) {
            fCurrent = (int)f[openPoints[i].x][openPoints[i].y]; //does this casting work?
            if (fCurrent < fBest) {
                fBest = fCurrent;
                bestIndex = i;
            }
        }
        index = bestIndex;
        return openPoints[bestIndex];
    }

    static List<Vector2UShort> AStarGetNeighbors(Vector2UShort loc, List<List<bool>> maze) {
        List<Vector2UShort> nbrs = new List<Vector2UShort>();
        //Vector2UShort foo = new Vector2UShort();
        Vector2UShort dim = new Vector2UShort((ushort)maze.Count, (ushort)maze[0].Count);

        /*//Load within boundaries
        if (loc.x > 0) {
            nbrs.Add(new Vector2UShort((ushort)(loc.x - 1), loc.y));
        }
        if (loc.x < (ushort)(dim.x - 1)) {
            nbrs.Add(new Vector2UShort((ushort)(loc.x + 1), loc.y));
        }
        if (loc.y > 0) {
            nbrs.Add(new Vector2UShort(loc.x, (ushort)(loc.y - 1)));
        }
        if (loc.y < (ushort)(dim.y - 1)) {
            nbrs.Add(new Vector2UShort(loc.x, (ushort)(loc.y + 1)));
        }*/

        bool left = loc.y > 0;
        bool right = loc.y < dim.y - 1;
        bool top = loc.x > 0;
        bool bottom = loc.x < dim.x - 1;

        List<List<bool>> map = new List<List<bool>> {
            new List<bool> { true, true, true },
            new List<bool> { true, false, true },
            new List<bool> { true, true, true },
        };

        //Remove invalid options
        if (!left) {
            map[0][0] = false;
            map[1][0] = false;
            map[2][0] = false;
        }
        if (!right) {
            map[0][2] = false;
            map[1][2] = false;
            map[2][2] = false;
        }
        if (!top) {
            map[0][0] = false;
            map[0][1] = false;
            map[0][2] = false;
        }
        if (!bottom) {
            map[2][0] = false;
            map[2][1] = false;
            map[2][2] = false;
        }

        //cout << map[0][0] << map[0][1] << map[0][2] << endl << map[1][0] << map[1][1] << map[1][2] << endl << map[2][0] << map[2][1] << map[2][2] << endl;

        //Load from map
        for (int i = 0; i < map.Count; ++i) {
            for (int j = 0; j < map.Count; ++j) {
                if (map[i][j]) {
                    nbrs.Add(new Vector2UShort((ushort)(loc.x + i - 1), (ushort)(loc.y + j - 1)));
                    //cout << i << j << " (" << foo[0] << "," << foo[1] << ")" << endl;
                }
            }
        }

        //Remove walls
        for (int i = 0; i < nbrs.Count; ++i) {
            if (maze[nbrs[i].x][nbrs[i].y] == true) {
                nbrs.RemoveAt(i);
                --i;
            }
        }

        //Debug.Log("nbrs size: " + nbrs.Count);

        return nbrs;
    }

    static void AStarConstructPath(ref List<Vector2UShort> path, List<List<Vector2UShort>> prev, Vector2UShort current, Vector2UShort start) {
        List<Vector2UShort> backPath = new List<Vector2UShort>() {
            new Vector2UShort(current.x, current.y)
        };
        Vector2UShort lastPoint;

        //Trace back to start
        while (!backPath[backPath.Count - 1].Equals(start)) {
            lastPoint = new Vector2UShort(prev[current.x][current.y].x, prev[current.x][current.y].y);
            current = new Vector2UShort(lastPoint.x, lastPoint.y);
            backPath.Add(new Vector2UShort(current.x, current.y));
        }

        //Flip it!
        for (int i = backPath.Count - 1; i >= 0; --i) {
            path.Add(new Vector2UShort(backPath[i].x, backPath[i].y));
        }
    }

    static bool AStar(ref List<Vector2UShort> path, Vector2UShort start, Vector2UShort end, List<List<bool>> maze) {
        //path = new List<Vector2UShort>();
        List<Vector2UShort> closed = new List<Vector2UShort>(); //Points already searched
        List<Vector2UShort> open = new List<Vector2UShort>(1337);
        open.Add(new Vector2UShort(start.x, start.y));
        List<List<Vector2UShort>> prev = new List<List<Vector2UShort>>(); //For each point, the best point to reach it from
        List<List<int>> gScore = new List<List<int>>(); //g(n) values
        List<List<double>> fScore = new List<List<double>>(); //f(n) values

        Vector2UShort emptyPoint = new Vector2UShort();

        //Populate gScore, fScore, and prev
        for (int i = 0; i < maze.Count; ++i) {
            gScore.Add(new List<int>()); //Empty vector
            fScore.Add(new List<double>());
            prev.Add(new List<Vector2UShort>());
            for (int j = 0; j < maze[i].Count; ++j) {
                gScore[i].Add(int.MaxValue);
                fScore[i].Add(int.MaxValue);                    ////!!!!!!
                prev[i].Add(emptyPoint);
            }
        }
        gScore[start.x][start.y] = 0; //The g(n) value for the start is 0.
        fScore[start.x][start.y] = AStarHeuristic(start, end);

        //Variables used in the loop (so memory doesn't have to be allocated with each loop)
        int currentPointIndex; ///IS THIS GOOD?
        Vector2UShort currentPoint = new Vector2UShort();
        List<Vector2UShort> neighbors = new List<Vector2UShort>();
        bool ifChecked = false;
        bool newNeighbor = false;
        double tentativeGScore;
        bool pathFound = false;

        //Main A* Loop
        int iters = 0;
        while (open.Count != 0u) {
            ++iters;
            currentPoint = AStarGetCurrentPoint(open, fScore, out currentPointIndex); //Open point with lowest fScore value.
            if (currentPoint.Equals(end)) {
                pathFound = true;
                AStarConstructPath(ref path, prev, currentPoint, start);
                break;
            }
            open.RemoveAt(currentPointIndex);
            closed.Add(currentPoint);


            neighbors = AStarGetNeighbors(currentPoint, maze);
            for (int i = 0; i < neighbors.Count; ++i) {
                ifChecked = false;
                for (int j = 0; j < closed.Count; ++j) {
                    if (neighbors[i].Equals(closed[j])) {
                        ifChecked = true;
                        break;
                    }
                }
                if (ifChecked) {
                    continue;
                }

                newNeighbor = true;
                for (int j = 0; j < open.Count; ++j) {
                    if (neighbors[i].Equals(open[j])) {
                        newNeighbor = false;
                        break;
                    }
                }
                if (newNeighbor) {
                    //Debug.Log("adding new neightbosdfjoj");
                    open.Add(neighbors[i]);
                }

                tentativeGScore = gScore[currentPoint.x][currentPoint.y] + 1;
                if (tentativeGScore >= gScore[neighbors[i].x][neighbors[i].y]) {
                    continue;
                }

                prev[neighbors[i].x][neighbors[i].y] = new Vector2UShort(currentPoint.x, currentPoint.y);
                gScore[neighbors[i].x][neighbors[i].y] = (int)tentativeGScore;
                fScore[neighbors[i].x][neighbors[i].y] = tentativeGScore + AStarHeuristic(neighbors[i], end);
            }

            //Debug.Log(open.Count + " | " + currentPoint.x + " " + currentPoint.y);
        }

        //Debug.Log("Total Iterations: " + iters);

        return pathFound;
    }

    public static void NavigateAStar(bool[,] grid, Vector2 start, Vector2 end, out List<Vector2> finalPath, out bool ifSuccessful) {

        List<Vector2UShort> finalPathUShort = new List<Vector2UShort>();

        List<List<bool>> maze = new List<List<bool>>();
        for (int i = 0; i < grid.GetLength(0); i++) {
            maze.Add(new List<bool>());
            for (int j = 0; j < grid.GetLength(1); j++) {
                maze[i].Add(grid[i, j]);
            }
        }

        ifSuccessful = AStar(ref finalPathUShort, new Vector2UShort((ushort)start.x, (ushort)start.y), new Vector2UShort((ushort)end.x, (ushort)end.y), maze);

        finalPath = new List<Vector2>();
        foreach (Vector2UShort v in finalPathUShort) {
            finalPath.Add(new Vector2(v.x, v.y));
        }
    }


    //public whatever;
    public static void TrollNavigation(bool[,] grid, Vector2 start, Vector2 end, out List<Vector2> finalPath) {
        finalPath = new List<Vector2>();
        finalPath.Add(start);
        for (int i = 1; i < 1000; i++) {
            finalPath.Add(finalPath[finalPath.Count - 1] + new Vector2(Mathf.Round(UnityEngine.Random.Range(-.5f, 1.5f)), Mathf.Round(UnityEngine.Random.Range(-1.5f, .5f))));
        }
    }

    public static void NavigateWallFollow(bool[,] grid, Vector2 start, Vector2 end, out List<Vector2> finalPath, out bool ifSuccessful, out bool ifTimedOut) {
        List<Vector2UShort> finalPathUShort = new List<Vector2UShort>();

        ifSuccessful = FollowWall(ref finalPathUShort, new Vector2UShort((ushort)start.x, (ushort)start.y), new Vector2UShort((ushort)end.x, (ushort)end.y), grid, out ifTimedOut);

        finalPath = new List<Vector2>();
        foreach (Vector2UShort v in finalPathUShort) {
            finalPath.Add(new Vector2(v.x, v.y));
        }
    }

    static bool FollowWall(ref List<Vector2UShort> finalPathUShort, Vector2UShort start, Vector2UShort end, bool[,] vector, out bool ifTimedOut) {

        ifTimedOut = false;

        for (int k = 0; k < vector.GetLength(0); k++) {
            vector[k, 0] = true;
            vector[k, vector.GetLength(1) - 1] = true;
        }
        for (int k = 0; k < vector.GetLength(1); k++) {
            vector[0, k] = true;
            vector[vector.GetLength(0) - 1, k] = true;
        }

        //position we are evaluating
        int posX = start.x;
        int posY = start.y;

        int endX = end.x;
        int endY = end.y;

        int direction = 1; //int to hold direction 0 = right 1 = left 2 = up 3 = down

        //get us against a wall
        while (vector[posX, posY - 1] == false) {
            posY--;
            finalPathUShort.Add(new Vector2UShort((ushort)posX, (ushort)posY));
        }

        int iter = 0;

        bool unsolved = true;
        while (unsolved) {
            try {
                if (direction == 0) {
                    if (vector[posX + 1, posY] == false && (vector[posX, posY - 1] == true || vector[posX, posY + 1] == true)) {
                        posX++;
                    }
                    else {
                        if (vector[posX, posY - 1] == false && (vector[posX + 1, posY - 1] == true || vector[posX - 1, posY - 1] == true)) {
                            direction = 3;
                            posY--;
                        }
                        else if (vector[posX, posY + 1] == false && (vector[posX + 1, posY + 1] == true || vector[posX - 1, posY + 1] == true)) {
                            direction = 2;
                            posY++;
                        }
                        else if (vector[posX, posY + 1] == false) {
                            direction = 2;
                            posY++;
                        }
                        else if (vector[posX, posY - 1] == false) {
                            direction = 3;
                            posY--;
                        }
                        else {
                            vector[posX, posY] = true;
                            posX--;
                        }
                    }
                }
                else if (direction == 1) {
                    if (vector[posX - 1, posY] == false && (vector[posX, posY - 1] == true || vector[posX, posY + 1] == true)) {
                        posX--;
                    }
                    else {
                        if (vector[posX, posY - 1] == false && (vector[posX + 1, posY - 1] == true || vector[posX - 1, posY - 1] == true)) {
                            direction = 3;
                            posY--;
                        }
                        else if (vector[posX, posY + 1] == false && (vector[posX + 1, posY + 1] == true || vector[posX - 1, posY + 1] == true)) {
                            direction = 2;
                            posY++;
                        }
                        else if (vector[posX, posY + 1] == false) {
                            direction = 2;
                            posY++;
                        }
                        else if (vector[posX, posY - 1] == false) {
                            direction = 3;
                            posY--;
                        }
                        else {
                            vector[posX, posY] = true;
                            posX++;
                        }
                    }
                }
                else if (direction == 2) {
                    if (vector[posX, posY + 1] == false && (vector[posX - 1, posY] == true || vector[posX + 1, posY] == true)) {
                        posY++;
                    }
                    else {
                        if (vector[posX + 1, posY] == false && (vector[posX + 1, posY + 1] == true || vector[posX + 1, posY - 1] == true)) {
                            direction = 0;
                            posX++;
                        }
                        else if (vector[posX - 1, posY] == false && (vector[posX - 1, posY + 1] == true || vector[posX - 1, posY - 1] == true)) {
                            posX--;
                            direction = 1;
                        }
                        else if (vector[posX + 1, posY] == false) {
                            direction = 0;
                            posX++;
                        }
                        else if (vector[posX - 1, posY] == false) {
                            direction = 1;
                            posX--;
                        }
                        else {
                            vector[posX, posY] = true;
                            posY--;
                        }
                    }
                }
                else if (direction == 3) {
                    if (vector[posX, posY - 1] == false && (vector[posX - 1, posY] == true || vector[posX + 1, posY] == true)) {
                        posY--;
                    }
                    else {
                        if (vector[posX + 1, posY] == false && (vector[posX + 1, posY + 1] == true || vector[posX + 1, posY - 1] == true)) {
                            direction = 0;
                            posX++;
                        }
                        else if (vector[posX - 1, posY] == false && (vector[posX - 1, posY + 1] == true || vector[posX - 1, posY - 1] == true)) {
                            direction = 1;
                            posX--;
                        }
                        else if (vector[posX + 1, posY] == false) {
                            direction = 0;
                            posX++;
                        }
                        else if (vector[posX - 1, posY] == false) {
                            direction = 1;
                            posX--;
                        }
                        else {
                            vector[posX, posY] = true;
                            posY++;
                        }
                    }
                }
            }
            catch (IndexOutOfRangeException) {
                //Invalid array index probably means we left the maze
                return false;
            }

            //draw pixel (KEEPS TRACK OF CURRENT VECTOR POSTION) (BASICALLY RECORDS EVERY MOVE BEING MADE PER ITERATION).
            finalPathUShort.Add(new Vector2UShort((ushort)posX, (ushort)posY));

            //condition if maze is solved
            if (posX > endX - 7 && posX < endX + 7) {
                if (posY > endY - 7 && posY < endY + 7) {
                    unsolved = false;
                }
            }
            iter++;
            if (iter > 10000000) { //cap iterations (10 million) so no infinite loop
                ifTimedOut = true;
                return false;
            }
        }

        return !unsolved;
    }
}
