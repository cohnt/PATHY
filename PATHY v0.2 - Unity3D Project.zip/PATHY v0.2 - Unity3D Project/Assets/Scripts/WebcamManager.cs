﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WebcamManager : MonoBehaviour {

    public GameObject buttonsPanel, giantMask;

    UIManager recentUICallback = null;
    WebCamTexture wct;

	// Use this for initialization
	void Start () {
        wct = new WebCamTexture();
        SetCameraUIActive(false);
	}

    public void StartWebcamInterface(UIManager uiCallback) {
        recentUICallback = uiCallback;
        SetCameraUIActive(true);
        GetComponent<RawImage>().texture = wct;
        wct.Play();
        Debug.Log(wct.width + " " + wct.height);
        GetComponent<RectTransform>().sizeDelta = new Vector2((float)wct.width / wct.height * 200f, 200);
    }

    public void TakePictureClick() {
        Texture2D photo = new Texture2D(wct.width, wct.height);
        photo.SetPixels(wct.GetPixels());
        photo.Apply();
        
        //Use the below line for saving to file
        //System.IO.File.WriteAllBytes("tempImage.png", photo.EncodeToPNG());

        StopWebcamInterface();

        if (recentUICallback != null) {
            recentUICallback.OnPictureTaken(photo);
        }
    }

    public void StopWebcamInterface() {
        wct.Stop();
        SetCameraUIActive(false);
    }

    public void SetCameraUIActive(bool ifActive) {
        GetComponent<RawImage>().enabled = ifActive;
        buttonsPanel.SetActive(ifActive);
        giantMask.SetActive(ifActive);
    }
}
